const button = document.getElementById("submit");
const html = document.getElementById("divId").innerHTML;

button.addEventListener("click", async _ => {
   try {
      const response = await fetch("http://localhost:3000/saveCheckListTemplate", {
         method:"post",
         body:html
      });
      console.log("Completed" + response);
   }
   catch(err) {
      console.log(err);
   }
});