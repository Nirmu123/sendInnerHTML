const express = require("express");
const bodyParser = require("body-parser");
const PORT = 3000;
const app = express();

app.use(bodyParser.text());

app.post("/saveCheckListTemplate", (req, res) => {
    let data = req.body;
    console.log(data);
});

app.listen(PORT, () => {
    console.log("Server is running");
});